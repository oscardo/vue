# graph-apollo-for-vue-class

## Instalation:
``` npm install ```

## Launch server:
``` npm start ```
